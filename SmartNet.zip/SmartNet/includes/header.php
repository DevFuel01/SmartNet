<?php

/**
 * Header Component
 * SmartNet - Digital Literacy Platform
 */

// Get current page for active navigation
$current_page = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="SmartNet - Learn digital literacy, stay safe online. Interactive quizzes, tips, and resources for safe internet usage.">
    <meta name="keywords" content="digital literacy, online safety, cybersecurity, phishing, password security, internet safety">
    <meta name="author" content="SmartNet">
    <title><?php echo isset($page_title) ? $page_title . ' - SmartNet' : 'SmartNet - Digital Literacy Platform'; ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>

<body>
    <header class="header">
        <nav class="navbar">
            <div class="container">
                <div class="nav-brand">
                    <i class="fas fa-shield-alt"></i>
                    <span>SmartNet</span>
                </div>

                <button class="nav-toggle" id="navToggle" aria-label="Toggle navigation">
                    <i class="fas fa-bars"></i>
                </button>

                <ul class="nav-menu" id="navMenu">
                    <li><a href="index.php" class="<?php echo ($current_page == 'index.php') ? 'active' : ''; ?>">Home</a></li>
                    <li><a href="quiz.php" class="<?php echo ($current_page == 'quiz.php' || $current_page == 'quiz-result.php') ? 'active' : ''; ?>">Quiz</a></li>
                    <li><a href="tips.php" class="<?php echo ($current_page == 'tips.php') ? 'active' : ''; ?>">Tips</a></li>
                    <li><a href="resources.php" class="<?php echo ($current_page == 'resources.php') ? 'active' : ''; ?>">Resources</a></li>
                    <li><a href="about.php" class="<?php echo ($current_page == 'about.php') ? 'active' : ''; ?>">About</a></li>
                </ul>
            </div>
        </nav>
    </header>

    <main class="main-content">
<?php
/**
 * Helper Functions
 * SmartNet - Digital Literacy Platform
 */

/**
 * Fetch all quiz questions with their options
 * @param PDO $pdo Database connection
 * @return array Array of questions with nested options
 */
function getQuizQuestions($pdo) {
    try {
        // Get all questions
        $stmt = $pdo->query("SELECT * FROM questions ORDER BY RAND()");
        $questions = $stmt->fetchAll();
        
        // Get options for each question
        foreach ($questions as &$question) {
            $stmt = $pdo->prepare("SELECT * FROM options WHERE question_id = ? ORDER BY RAND()");
            $stmt->execute([$question['id']]);
            $question['options'] = $stmt->fetchAll();
        }
        
        return $questions;
    } catch (PDOException $e) {
        error_log("Error fetching quiz questions: " . $e->getMessage());
        return [];
    }
}

/**
 * Calculate quiz score based on submitted answers
 * @param PDO $pdo Database connection
 * @param array $answers User's submitted answers [question_id => option_id]
 * @return array Score data with details
 */
function calculateScore($pdo, $answers) {
    try {
        $score = 0;
        $total = count($answers);
        $results = [];
        
        foreach ($answers as $questionId => $optionId) {
            // Get the correct answer
            $stmt = $pdo->prepare("
                SELECT o.is_correct, q.question_text, q.explanation, o.option_text
                FROM options o
                JOIN questions q ON o.question_id = q.id
                WHERE o.id = ? AND q.id = ?
            ");
            $stmt->execute([$optionId, $questionId]);
            $result = $stmt->fetch();
            
            if ($result && $result['is_correct']) {
                $score++;
            }
            
            // Get correct option for this question
            $stmt = $pdo->prepare("
                SELECT option_text 
                FROM options 
                WHERE question_id = ? AND is_correct = 1
            ");
            $stmt->execute([$questionId]);
            $correctOption = $stmt->fetch();
            
            $results[] = [
                'question' => $result['question_text'] ?? 'Unknown',
                'user_answer' => $result['option_text'] ?? 'Unknown',
                'correct_answer' => $correctOption['option_text'] ?? 'Unknown',
                'is_correct' => $result['is_correct'] ?? false,
                'explanation' => $result['explanation'] ?? ''
            ];
        }
        
        $percentage = ($total > 0) ? round(($score / $total) * 100, 2) : 0;
        
        return [
            'score' => $score,
            'total' => $total,
            'percentage' => $percentage,
            'results' => $results
        ];
    } catch (PDOException $e) {
        error_log("Error calculating score: " . $e->getMessage());
        return [
            'score' => 0,
            'total' => 0,
            'percentage' => 0,
            'results' => []
        ];
    }
}

/**
 * Store quiz result in database
 * @param PDO $pdo Database connection
 * @param int $score User's score
 * @param int $total Total questions
 * @param float $percentage Percentage score
 * @param string $name Optional user name
 * @param string $email Optional user email
 * @return bool Success status
 */
function storeQuizResult($pdo, $score, $total, $percentage, $name = 'Anonymous', $email = null) {
    try {
        $stmt = $pdo->prepare("
            INSERT INTO quiz_results (user_name, user_email, score, total_questions, percentage)
            VALUES (?, ?, ?, ?, ?)
        ");
        return $stmt->execute([$name, $email, $score, $total, $percentage]);
    } catch (PDOException $e) {
        error_log("Error storing quiz result: " . $e->getMessage());
        return false;
    }
}

/**
 * Sanitize user input to prevent XSS
 * @param string $data Input data
 * @return string Sanitized data
 */
function sanitizeInput($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
    return $data;
}

/**
 * Validate email address
 * @param string $email Email to validate
 * @return bool Valid status
 */
function isValidEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

/**
 * Get performance message based on percentage
 * @param float $percentage Score percentage
 * @return string Performance message
 */
function getPerformanceMessage($percentage) {
    if ($percentage >= 90) {
        return "Excellent! You're a digital literacy expert! 🌟";
    } elseif ($percentage >= 70) {
        return "Great job! You have strong digital safety knowledge. 👍";
    } elseif ($percentage >= 50) {
        return "Good effort! Review the tips to improve your digital safety. 📚";
    } else {
        return "Keep learning! Check out our tips and resources to stay safe online. 💪";
    }
}
?>

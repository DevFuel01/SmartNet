<?php

/**
 * Resources Page
 * SmartNet - Digital Literacy Platform
 */

$page_title = 'Learning Resources';
include 'includes/header.php';
?>

<section class="resources-section">
    <div class="container">
        <div class="page-header">
            <h1><i class="fas fa-book"></i> Learning Resources</h1>
            <p>Curated materials from trusted cybersecurity experts</p>
        </div>

        <!-- Cybersecurity Basics -->
        <div class="resource-category">
            <h2><i class="fas fa-graduation-cap"></i> Cybersecurity Basics</h2>
            <div class="resources-grid">
                <div class="resource-card">
                    <div class="resource-icon">
                        <i class="fas fa-shield-alt"></i>
                    </div>
                    <h3>Stay Safe Online</h3>
                    <p>Comprehensive guide to online safety from the National Cyber Security Alliance. Covers passwords, privacy, and scam prevention.</p>
                    <a href="https://staysafeonline.org/" target="_blank" rel="noopener" class="resource-link">
                        Visit Resource <i class="fas fa-external-link-alt"></i>
                    </a>
                </div>

                <div class="resource-card">
                    <div class="resource-icon">
                        <i class="fas fa-user-shield"></i>
                    </div>
                    <h3>Google Safety Center</h3>
                    <p>Learn how to protect your Google account, manage privacy settings, and secure your data across Google services.</p>
                    <a href="https://safety.google/" target="_blank" rel="noopener" class="resource-link">
                        Visit Resource <i class="fas fa-external-link-alt"></i>
                    </a>
                </div>

                <div class="resource-card">
                    <div class="resource-icon">
                        <i class="fas fa-laptop-code"></i>
                    </div>
                    <h3>Cyber.org</h3>
                    <p>Free cybersecurity education resources for learners of all ages. Interactive courses and practical exercises.</p>
                    <a href="https://cyber.org/" target="_blank" rel="noopener" class="resource-link">
                        Visit Resource <i class="fas fa-external-link-alt"></i>
                    </a>
                </div>
            </div>
        </div>

        <!-- Privacy & Data Protection -->
        <div class="resource-category">
            <h2><i class="fas fa-lock"></i> Privacy & Data Protection</h2>
            <div class="resources-grid">
                <div class="resource-card">
                    <div class="resource-icon">
                        <i class="fas fa-eye-slash"></i>
                    </div>
                    <h3>Privacy Rights Clearinghouse</h3>
                    <p>Understand your privacy rights and learn how to protect your personal information online and offline.</p>
                    <a href="https://privacyrights.org/" target="_blank" rel="noopener" class="resource-link">
                        Visit Resource <i class="fas fa-external-link-alt"></i>
                    </a>
                </div>

                <div class="resource-card">
                    <div class="resource-icon">
                        <i class="fas fa-database"></i>
                    </div>
                    <h3>Have I Been Pwned</h3>
                    <p>Check if your email or password has been compromised in a data breach. Free service by security expert Troy Hunt.</p>
                    <a href="https://haveibeenpwned.com/" target="_blank" rel="noopener" class="resource-link">
                        Visit Resource <i class="fas fa-external-link-alt"></i>
                    </a>
                </div>

                <div class="resource-card">
                    <div class="resource-icon">
                        <i class="fas fa-user-secret"></i>
                    </div>
                    <h3>Electronic Frontier Foundation</h3>
                    <p>Digital privacy guides, tools, and resources to protect your rights in the digital world.</p>
                    <a href="https://www.eff.org/issues/privacy" target="_blank" rel="noopener" class="resource-link">
                        Visit Resource <i class="fas fa-external-link-alt"></i>
                    </a>
                </div>
            </div>
        </div>

        <!-- Scam Awareness -->
        <div class="resource-category">
            <h2><i class="fas fa-exclamation-triangle"></i> Scam Awareness</h2>
            <div class="resources-grid">
                <div class="resource-card">
                    <div class="resource-icon">
                        <i class="fas fa-flag"></i>
                    </div>
                    <h3>FTC Consumer Alerts</h3>
                    <p>Latest scam alerts and fraud warnings from the Federal Trade Commission. Learn to spot and report scams.</p>
                    <a href="https://consumer.ftc.gov/consumer-alerts" target="_blank" rel="noopener" class="resource-link">
                        Visit Resource <i class="fas fa-external-link-alt"></i>
                    </a>
                </div>

                <div class="resource-card">
                    <div class="resource-icon">
                        <i class="fas fa-fish"></i>
                    </div>
                    <h3>Anti-Phishing Working Group</h3>
                    <p>Global coalition fighting phishing and cybercrime. Access reports, trends, and educational materials.</p>
                    <a href="https://apwg.org/" target="_blank" rel="noopener" class="resource-link">
                        Visit Resource <i class="fas fa-external-link-alt"></i>
                    </a>
                </div>

                <div class="resource-card">
                    <div class="resource-icon">
                        <i class="fas fa-envelope"></i>
                    </div>
                    <h3>PhishTank</h3>
                    <p>Community-driven database of phishing websites. Verify suspicious links and report new phishing attempts.</p>
                    <a href="https://phishtank.org/" target="_blank" rel="noopener" class="resource-link">
                        Visit Resource <i class="fas fa-external-link-alt"></i>
                    </a>
                </div>
            </div>
        </div>

        <!-- Tools & Software -->
        <div class="resource-category">
            <h2><i class="fas fa-tools"></i> Security Tools</h2>
            <div class="resources-grid">
                <div class="resource-card">
                    <div class="resource-icon">
                        <i class="fas fa-key"></i>
                    </div>
                    <h3>Password Managers</h3>
                    <p><strong>Recommended:</strong> Bitwarden (free & open-source), LastPass, 1Password, Dashlane</p>
                    <a href="https://bitwarden.com/" target="_blank" rel="noopener" class="resource-link">
                        Try Bitwarden <i class="fas fa-external-link-alt"></i>
                    </a>
                </div>

                <div class="resource-card">
                    <div class="resource-icon">
                        <i class="fas fa-network-wired"></i>
                    </div>
                    <h3>VPN Services</h3>
                    <p><strong>Recommended:</strong> ProtonVPN (free tier), NordVPN, ExpressVPN, Mullvad</p>
                    <a href="https://protonvpn.com/" target="_blank" rel="noopener" class="resource-link">
                        Try ProtonVPN <i class="fas fa-external-link-alt"></i>
                    </a>
                </div>

                <div class="resource-card">
                    <div class="resource-icon">
                        <i class="fas fa-mobile-alt"></i>
                    </div>
                    <h3>Two-Factor Authentication Apps</h3>
                    <p><strong>Recommended:</strong> Google Authenticator, Authy, Microsoft Authenticator</p>
                    <a href="https://authy.com/" target="_blank" rel="noopener" class="resource-link">
                        Get Authy <i class="fas fa-external-link-alt"></i>
                    </a>
                </div>
            </div>
        </div>

        <!-- Additional Learning -->
        <div class="learning-box">
            <h2><i class="fas fa-star"></i> Continue Your Learning Journey</h2>
            <p>Digital literacy is an ongoing process. Stay informed about the latest threats and best practices:</p>
            <ul class="learning-list">
                <li><i class="fas fa-check-circle"></i> Subscribe to security newsletters (e.g., Krebs on Security, The Hacker News)</li>
                <li><i class="fas fa-check-circle"></i> Follow cybersecurity experts on social media</li>
                <li><i class="fas fa-check-circle"></i> Take free online courses (Coursera, edX, Cybrary)</li>
                <li><i class="fas fa-check-circle"></i> Practice with our quiz regularly to reinforce your knowledge</li>
                <li><i class="fas fa-check-circle"></i> Share what you learn with friends and family</li>
            </ul>
        </div>

        <div class="resources-cta">
            <p>Ready to test what you've learned?</p>
            <a href="quiz.php" class="btn btn-primary">Take the Quiz</a>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
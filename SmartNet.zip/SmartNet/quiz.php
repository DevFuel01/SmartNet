<?php

/**
 * Quiz Page
 * SmartNet - Digital Literacy Platform
 */

require_once 'config/database.php';
require_once 'includes/functions.php';

$page_title = 'Digital Literacy Quiz';

// Fetch quiz questions
$questions = getQuizQuestions($pdo);

if (empty($questions)) {
    die("Error loading quiz questions. Please ensure the database is set up correctly.");
}

include 'includes/header.php';
?>

<section class="quiz-section">
    <div class="container">
        <div class="quiz-header">
            <h1><i class="fas fa-clipboard-list"></i> Digital Literacy Quiz</h1>
            <p>Test your knowledge about online safety and digital security</p>
            <div class="quiz-info">
                <span><i class="fas fa-question-circle"></i> <?php echo count($questions); ?> Questions</span>
                <span><i class="fas fa-clock"></i> ~5 minutes</span>
            </div>
        </div>

        <form method="POST" action="quiz-result.php" class="quiz-form" id="quizForm">
            <?php foreach ($questions as $index => $question): ?>
                <div class="question-card">
                    <div class="question-header">
                        <span class="question-number">Question <?php echo $index + 1; ?></span>
                        <span class="question-category"><?php echo htmlspecialchars($question['category']); ?></span>
                    </div>

                    <h3 class="question-text"><?php echo htmlspecialchars($question['question_text']); ?></h3>

                    <div class="options-list">
                        <?php foreach ($question['options'] as $option): ?>
                            <label class="option-label">
                                <input
                                    type="radio"
                                    name="question_<?php echo $question['id']; ?>"
                                    value="<?php echo $option['id']; ?>"
                                    required>
                                <span class="option-text"><?php echo htmlspecialchars($option['option_text']); ?></span>
                                <span class="option-checkmark"></span>
                            </label>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endforeach; ?>

            <div class="quiz-footer">
                <button type="submit" class="btn btn-primary btn-large">
                    <i class="fas fa-check-circle"></i> Submit Quiz
                </button>
            </div>
        </form>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
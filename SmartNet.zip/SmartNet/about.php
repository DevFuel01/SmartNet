<?php

/**
 * About Page
 * SmartNet - Digital Literacy Platform
 */

$page_title = 'About Us';
include 'includes/header.php';
?>

<section class="about-section">
    <div class="container">
        <div class="page-header">
            <h1><i class="fas fa-info-circle"></i> About SmartNet</h1>
            <p>Empowering digital literacy for a safer internet</p>
        </div>

        <!-- Mission -->
        <div class="about-content">
            <div class="about-card">
                <h2><i class="fas fa-bullseye"></i> Our Mission</h2>
                <p>SmartNet exists to bridge the digital literacy gap and protect vulnerable internet users from online threats. We believe everyone deserves to navigate the internet safely and confidently.</p>
                <p>Through interactive education, practical tips, and curated resources, we empower users to recognize scams, protect their privacy, and make informed decisions online.</p>
            </div>

            <!-- Problem Statement -->
            <div class="about-card highlight">
                <h2><i class="fas fa-exclamation-circle"></i> The Problem We're Solving</h2>
                <div class="problem-stats">
                    <div class="stat">
                        <h3>$10.3 Billion</h3>
                        <p>Lost to online scams in 2023 alone</p>
                    </div>
                    <div class="stat">
                        <h3>3.4 Billion</h3>
                        <p>Phishing emails sent every day</p>
                    </div>
                    <div class="stat">
                        <h3>80%</h3>
                        <p>Of data breaches involve weak passwords</p>
                    </div>
                </div>
                <p>Many people lack basic digital literacy skills, making them easy targets for cybercriminals. From elderly users falling for phone scams to students sharing too much on social media, the need for digital education has never been greater.</p>
            </div>

            <!-- Who We Help -->
            <div class="about-card">
                <h2><i class="fas fa-users"></i> Who We Help</h2>
                <div class="audience-grid">
                    <div class="audience-item">
                        <i class="fas fa-user-graduate"></i>
                        <h3>Students</h3>
                        <p>Learn safe social media practices and protect personal information</p>
                    </div>
                    <div class="audience-item">
                        <i class="fas fa-user-tie"></i>
                        <h3>Professionals</h3>
                        <p>Recognize phishing attempts and secure work accounts</p>
                    </div>
                    <div class="audience-item">
                        <i class="fas fa-user-friends"></i>
                        <h3>Seniors</h3>
                        <p>Avoid scams targeting older adults and protect savings</p>
                    </div>
                    <div class="audience-item">
                        <i class="fas fa-globe"></i>
                        <h3>Everyone</h3>
                        <p>Build fundamental digital safety skills for daily internet use</p>
                    </div>
                </div>
            </div>

            <!-- Features -->
            <div class="about-card">
                <h2><i class="fas fa-star"></i> What We Offer</h2>
                <div class="features-list">
                    <div class="feature-item">
                        <i class="fas fa-question-circle"></i>
                        <div>
                            <h3>Interactive Quiz</h3>
                            <p>Test your digital literacy knowledge with 10 comprehensive questions covering password security, phishing, social media safety, and safe browsing. Get instant feedback with detailed explanations.</p>
                        </div>
                    </div>
                    <div class="feature-item">
                        <i class="fas fa-lightbulb"></i>
                        <div>
                            <h3>Practical Safety Tips</h3>
                            <p>Actionable advice organized by category: password security, phishing awareness, social media safety, and safe browsing. Each tip includes real-world examples and immediate actions you can take.</p>
                        </div>
                    </div>
                    <div class="feature-item">
                        <i class="fas fa-book"></i>
                        <div>
                            <h3>Curated Resources</h3>
                            <p>Access trusted learning materials from cybersecurity experts, government agencies, and privacy advocates. We've done the research so you don't have to.</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Technology Stack -->
            <div class="about-card">
                <h2><i class="fas fa-code"></i> Technology Stack</h2>
                <p>SmartNet is built with clean, secure, and maintainable code:</p>
                <div class="tech-stack">
                    <div class="tech-item">
                        <i class="fab fa-html5"></i>
                        <span>HTML5</span>
                    </div>
                    <div class="tech-item">
                        <i class="fab fa-css3-alt"></i>
                        <span>CSS3</span>
                    </div>
                    <div class="tech-item">
                        <i class="fab fa-js"></i>
                        <span>JavaScript</span>
                    </div>
                    <div class="tech-item">
                        <i class="fab fa-php"></i>
                        <span>PHP (PDO)</span>
                    </div>
                    <div class="tech-item">
                        <i class="fas fa-database"></i>
                        <span>MySQL</span>
                    </div>
                </div>
                <p class="tech-note"><strong>Security First:</strong> We use PDO prepared statements to prevent SQL injection, input sanitization to prevent XSS attacks, and follow security best practices throughout.</p>
            </div>

            <!-- Impact -->
            <div class="about-card highlight">
                <h2><i class="fas fa-heart"></i> Social Impact</h2>
                <p>Every user who completes our quiz and applies our tips becomes more resilient against online threats. By sharing knowledge freely and making digital literacy accessible, we're creating a safer internet for everyone.</p>
                <div class="impact-goals">
                    <div class="goal">
                        <i class="fas fa-check-circle"></i>
                        <span>Reduce successful phishing attacks</span>
                    </div>
                    <div class="goal">
                        <i class="fas fa-check-circle"></i>
                        <span>Prevent financial losses from scams</span>
                    </div>
                    <div class="goal">
                        <i class="fas fa-check-circle"></i>
                        <span>Protect personal privacy online</span>
                    </div>
                    <div class="goal">
                        <i class="fas fa-check-circle"></i>
                        <span>Build confident, informed internet users</span>
                    </div>
                </div>
            </div>

            <!-- Hackathon Context -->
            <div class="about-card">
                <h2><i class="fas fa-trophy"></i> Hackathon Project</h2>
                <p>SmartNet was developed for an online hackathon focused on social impact and innovation. This project demonstrates:</p>
                <ul class="hackathon-list">
                    <li><strong>Creativity:</strong> Interactive quiz system with real-time scoring and explanations</li>
                    <li><strong>Technical Implementation:</strong> Secure full-stack application with clean architecture</li>
                    <li><strong>Impact:</strong> Addresses real-world problem affecting millions of internet users</li>
                    <li><strong>Usability:</strong> Beginner-friendly interface accessible to all skill levels</li>
                    <li><strong>Completeness:</strong> Fully functional platform ready for immediate use</li>
                </ul>
            </div>
        </div>

        <div class="about-cta">
            <h2>Join the Movement for Digital Literacy</h2>
            <p>Start learning today and help create a safer internet for everyone</p>
            <a href="quiz.php" class="btn btn-primary btn-large">Take the Quiz</a>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
-- SmartNet Database Schema
-- Digital Literacy Platform
-- Created: 2025-12-26

-- Create database
CREATE DATABASE IF NOT EXISTS smartnet CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE smartnet;

-- ============================================
-- Table: questions
-- Stores quiz questions about digital literacy
-- ============================================
CREATE TABLE IF NOT EXISTS questions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    question_text TEXT NOT NULL,
    category VARCHAR(100) NOT NULL,
    difficulty ENUM('easy', 'medium', 'hard') DEFAULT 'medium',
    explanation TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_category (category),
    INDEX idx_difficulty (difficulty)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- Table: options
-- Stores multiple-choice options for questions
-- ============================================
CREATE TABLE IF NOT EXISTS options (
    id INT AUTO_INCREMENT PRIMARY KEY,
    question_id INT NOT NULL,
    option_text TEXT NOT NULL,
    is_correct BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (question_id) REFERENCES questions(id) ON DELETE CASCADE,
    INDEX idx_question_id (question_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- Table: quiz_results
-- Stores anonymous quiz attempts
-- ============================================
CREATE TABLE IF NOT EXISTS quiz_results (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_name VARCHAR(255) DEFAULT 'Anonymous',
    user_email VARCHAR(255) DEFAULT NULL,
    score INT NOT NULL,
    total_questions INT NOT NULL,
    percentage DECIMAL(5,2) NOT NULL,
    completed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_completed_at (completed_at),
    INDEX idx_percentage (percentage)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- SEED DATA: Sample Quiz Questions
-- ============================================

-- Question 1: Password Security
INSERT INTO questions (question_text, category, difficulty, explanation) VALUES
('What makes a password strong and secure?', 'Password Security', 'easy', 
'A strong password should be at least 12 characters long and include a mix of uppercase letters, lowercase letters, numbers, and special symbols. This makes it much harder for hackers to crack using brute force attacks.');

INSERT INTO options (question_id, option_text, is_correct) VALUES
(1, 'Your name and birth year', FALSE),
(1, 'At least 12 characters with letters, numbers, and symbols', TRUE),
(1, 'A simple word you can remember easily', FALSE),
(1, 'Your phone number', FALSE);

-- Question 2: Phishing Awareness
INSERT INTO questions (question_text, category, difficulty, explanation) VALUES
('Which of these is a common sign of a phishing email?', 'Phishing & Scams', 'medium',
'Phishing emails often create urgency, contain spelling errors, use suspicious links, and ask for sensitive information. Always verify the sender before clicking links or providing personal data.');

INSERT INTO options (question_id, option_text, is_correct) VALUES
(2, 'Professional company logo', FALSE),
(2, 'Urgent request to verify your account immediately', TRUE),
(2, 'Personalized greeting with your name', FALSE),
(2, 'Clear contact information', FALSE);

-- Question 3: Two-Factor Authentication
INSERT INTO questions (question_text, category, difficulty, explanation) VALUES
('What is two-factor authentication (2FA)?', 'Account Security', 'easy',
'Two-factor authentication adds an extra layer of security by requiring two forms of verification: something you know (password) and something you have (phone, security key, or authentication app).');

INSERT INTO options (question_id, option_text, is_correct) VALUES
(3, 'Using two different passwords', FALSE),
(3, 'A security method requiring password + additional verification code', TRUE),
(3, 'Logging in from two devices', FALSE),
(3, 'Having two email accounts', FALSE);

-- Question 4: Public WiFi Safety
INSERT INTO questions (question_text, category, difficulty, explanation) VALUES
('What should you avoid doing on public WiFi networks?', 'Safe Browsing', 'medium',
'Public WiFi networks are often unsecured, making it easy for hackers to intercept your data. Avoid accessing sensitive accounts, banking, or entering passwords on public WiFi without a VPN.');

INSERT INTO options (question_id, option_text, is_correct) VALUES
(4, 'Browsing news websites', FALSE),
(4, 'Accessing your bank account', TRUE),
(4, 'Reading emails (without clicking links)', FALSE),
(4, 'Watching videos', FALSE);

-- Question 5: Social Media Privacy
INSERT INTO questions (question_text, category, difficulty, explanation) VALUES
('Which information should you avoid sharing publicly on social media?', 'Social Media Safety', 'easy',
'Sharing your location, travel plans, or daily routines can make you vulnerable to stalking, burglary, or identity theft. Keep personal details private and review your privacy settings regularly.');

INSERT INTO options (question_id, option_text, is_correct) VALUES
(5, 'Your favorite hobbies', FALSE),
(5, 'Your current location and travel plans', TRUE),
(5, 'Photos of your pets', FALSE),
(5, 'Your favorite quotes', FALSE);

-- Question 6: Software Updates
INSERT INTO questions (question_text, category, difficulty, explanation) VALUES
('Why is it important to install software updates regularly?', 'Device Security', 'medium',
'Software updates often include critical security patches that fix vulnerabilities hackers could exploit. Delaying updates leaves your device exposed to known security risks.');

INSERT INTO options (question_id, option_text, is_correct) VALUES
(6, 'To get new features only', FALSE),
(6, 'To fix security vulnerabilities and protect against threats', TRUE),
(6, 'Updates are not important', FALSE),
(6, 'Only to improve app appearance', FALSE);

-- Question 7: Suspicious Links
INSERT INTO questions (question_text, category, difficulty, explanation) VALUES
('What should you do if you receive a suspicious link via email or text?', 'Phishing & Scams', 'easy',
'Never click suspicious links. Hover over links to check the actual URL, verify the sender through official channels, and report phishing attempts to protect yourself and others.');

INSERT INTO options (question_id, option_text, is_correct) VALUES
(7, 'Click it to see where it goes', FALSE),
(7, 'Ignore and delete the message, or report it as phishing', TRUE),
(7, 'Forward it to friends to check', FALSE),
(7, 'Reply asking if it is legitimate', FALSE);

-- Question 8: Password Reuse
INSERT INTO questions (question_text, category, difficulty, explanation) VALUES
('Why should you avoid using the same password for multiple accounts?', 'Password Security', 'medium',
'If one account is compromised, hackers will try that password on other services. Using unique passwords for each account limits damage from data breaches. Use a password manager to help manage multiple passwords.');

INSERT INTO options (question_id, option_text, is_correct) VALUES
(8, 'It is easier to remember one password', FALSE),
(8, 'If one account is hacked, all accounts become vulnerable', TRUE),
(8, 'There is no risk in reusing passwords', FALSE),
(8, 'Websites require different passwords', FALSE);

-- Question 9: HTTPS Security
INSERT INTO questions (question_text, category, difficulty, explanation) VALUES
('What does "HTTPS" in a website URL indicate?', 'Safe Browsing', 'medium',
'HTTPS (HyperText Transfer Protocol Secure) means the connection between your browser and the website is encrypted. Always look for HTTPS and a padlock icon before entering sensitive information.');

INSERT INTO options (question_id, option_text, is_correct) VALUES
(9, 'The website is popular', FALSE),
(9, 'The connection is encrypted and more secure', TRUE),
(9, 'The website loads faster', FALSE),
(9, 'The website is free to use', FALSE);

-- Question 10: App Permissions
INSERT INTO questions (question_text, category, difficulty, explanation) VALUES
('What should you check before installing a mobile app?', 'Device Security', 'hard',
'Always review app permissions before installing. Be suspicious if an app requests access to data or features it does not need (e.g., a flashlight app requesting contacts). Only download apps from official stores.');

INSERT INTO options (question_id, option_text, is_correct) VALUES
(10, 'Only the app icon design', FALSE),
(10, 'The permissions it requests and reviews from other users', TRUE),
(10, 'Just the app size', FALSE),
(10, 'Only the number of downloads', FALSE);

-- ============================================
-- Verification Queries
-- ============================================
-- SELECT COUNT(*) as total_questions FROM questions;
-- SELECT COUNT(*) as total_options FROM options;
-- SELECT q.question_text, o.option_text, o.is_correct FROM questions q JOIN options o ON q.id = o.question_id;

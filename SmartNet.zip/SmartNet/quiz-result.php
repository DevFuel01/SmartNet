<?php

/**
 * Quiz Result Page
 * SmartNet - Digital Literacy Platform
 */

require_once 'config/database.php';
require_once 'includes/functions.php';

$page_title = 'Quiz Results';

// Check if form was submitted
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: quiz.php');
    exit;
}

// Collect answers
$answers = [];
foreach ($_POST as $key => $value) {
    if (strpos($key, 'question_') === 0) {
        $questionId = str_replace('question_', '', $key);
        $answers[$questionId] = $value;
    }
}

// Calculate score
$scoreData = calculateScore($pdo, $answers);

// Store result
storeQuizResult(
    $pdo,
    $scoreData['score'],
    $scoreData['total'],
    $scoreData['percentage']
);

// Get performance message
$performanceMsg = getPerformanceMessage($scoreData['percentage']);

include 'includes/header.php';
?>

<section class="result-section">
    <div class="container">
        <div class="result-header">
            <h1><i class="fas fa-trophy"></i> Quiz Results</h1>
        </div>

        <!-- Score Card -->
        <div class="score-card">
            <div class="score-circle">
                <svg viewBox="0 0 200 200">
                    <circle cx="100" cy="100" r="90" class="score-bg"></circle>
                    <circle
                        cx="100"
                        cy="100"
                        r="90"
                        class="score-progress"
                        style="stroke-dashoffset: <?php echo 565 - (565 * $scoreData['percentage'] / 100); ?>"></circle>
                </svg>
                <div class="score-text">
                    <span class="score-percentage"><?php echo $scoreData['percentage']; ?>%</span>
                    <span class="score-label"><?php echo $scoreData['score']; ?> / <?php echo $scoreData['total']; ?></span>
                </div>
            </div>

            <h2 class="performance-message"><?php echo $performanceMsg; ?></h2>
        </div>

        <!-- Detailed Results -->
        <div class="results-details">
            <h3><i class="fas fa-list-check"></i> Answer Review</h3>

            <?php foreach ($scoreData['results'] as $index => $result): ?>
                <div class="result-item <?php echo $result['is_correct'] ? 'correct' : 'incorrect'; ?>">
                    <div class="result-header">
                        <span class="result-number">Question <?php echo $index + 1; ?></span>
                        <span class="result-status">
                            <?php if ($result['is_correct']): ?>
                                <i class="fas fa-check-circle"></i> Correct
                            <?php else: ?>
                                <i class="fas fa-times-circle"></i> Incorrect
                            <?php endif; ?>
                        </span>
                    </div>

                    <p class="result-question"><?php echo htmlspecialchars($result['question']); ?></p>

                    <div class="result-answers">
                        <p class="user-answer">
                            <strong>Your answer:</strong> <?php echo htmlspecialchars($result['user_answer']); ?>
                        </p>
                        <?php if (!$result['is_correct']): ?>
                            <p class="correct-answer">
                                <strong>Correct answer:</strong> <?php echo htmlspecialchars($result['correct_answer']); ?>
                            </p>
                        <?php endif; ?>
                    </div>

                    <?php if (!empty($result['explanation'])): ?>
                        <div class="result-explanation">
                            <i class="fas fa-info-circle"></i>
                            <p><?php echo htmlspecialchars($result['explanation']); ?></p>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>

        <!-- Action Buttons -->
        <div class="result-actions">
            <a href="quiz.php" class="btn btn-secondary">
                <i class="fas fa-redo"></i> Retake Quiz
            </a>
            <a href="tips.php" class="btn btn-primary">
                <i class="fas fa-lightbulb"></i> Learn Safety Tips
            </a>
            <a href="resources.php" class="btn btn-secondary">
                <i class="fas fa-book"></i> View Resources
            </a>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
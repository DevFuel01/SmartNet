<?php

/**
 * Tips Page
 * SmartNet - Digital Literacy Platform
 */

$page_title = 'Safety Tips';
include 'includes/header.php';
?>

<section class="tips-section">
    <div class="container">
        <div class="page-header">
            <h1><i class="fas fa-lightbulb"></i> Digital Safety Tips</h1>
            <p>Practical advice to protect yourself online</p>
        </div>

        <!-- Password Security -->
        <div class="tips-category">
            <h2><i class="fas fa-lock"></i> Password Security</h2>
            <div class="tips-grid">
                <div class="tip-card">
                    <div class="tip-icon">
                        <i class="fas fa-key"></i>
                    </div>
                    <h3>Create Strong Passwords</h3>
                    <p>Use at least 12 characters with a mix of uppercase, lowercase, numbers, and symbols. Avoid dictionary words, names, or dates.</p>
                    <div class="tip-example">
                        <strong>Example:</strong> <code>Tr0p!c@lSun$et#2024</code>
                    </div>
                </div>

                <div class="tip-card">
                    <div class="tip-icon">
                        <i class="fas fa-ban"></i>
                    </div>
                    <h3>Never Reuse Passwords</h3>
                    <p>Use a unique password for each account. If one account is breached, others remain safe.</p>
                    <div class="tip-example">
                        <strong>Tip:</strong> Use a password manager like Bitwarden or LastPass
                    </div>
                </div>

                <div class="tip-card">
                    <div class="tip-icon">
                        <i class="fas fa-mobile-alt"></i>
                    </div>
                    <h3>Enable Two-Factor Authentication</h3>
                    <p>Add an extra layer of security with 2FA. Even if your password is stolen, attackers can't access your account.</p>
                    <div class="tip-example">
                        <strong>Use:</strong> Google Authenticator, Authy, or SMS codes
                    </div>
                </div>
            </div>
        </div>

        <!-- Phishing & Scams -->
        <div class="tips-category">
            <h2><i class="fas fa-fish"></i> Phishing & Scams</h2>
            <div class="tips-grid">
                <div class="tip-card">
                    <div class="tip-icon">
                        <i class="fas fa-exclamation-triangle"></i>
                    </div>
                    <h3>Recognize Red Flags</h3>
                    <p>Watch for urgent language, spelling errors, suspicious sender addresses, and requests for personal information.</p>
                    <div class="tip-example">
                        <strong>Red Flag:</strong> "Your account will be closed in 24 hours!"
                    </div>
                </div>

                <div class="tip-card">
                    <div class="tip-icon">
                        <i class="fas fa-mouse-pointer"></i>
                    </div>
                    <h3>Hover Before Clicking</h3>
                    <p>Hover over links to see the actual URL before clicking. Phishing links often mimic legitimate websites.</p>
                    <div class="tip-example">
                        <strong>Fake:</strong> paypa1.com (notice the "1" instead of "l")
                    </div>
                </div>

                <div class="tip-card">
                    <div class="tip-icon">
                        <i class="fas fa-phone"></i>
                    </div>
                    <h3>Verify Directly</h3>
                    <p>If you receive a suspicious message claiming to be from a company, contact them directly using official contact info.</p>
                    <div class="tip-example">
                        <strong>Don't:</strong> Use contact info from the suspicious email
                    </div>
                </div>
            </div>
        </div>

        <!-- Social Media Safety -->
        <div class="tips-category">
            <h2><i class="fas fa-users"></i> Social Media Safety</h2>
            <div class="tips-grid">
                <div class="tip-card">
                    <div class="tip-icon">
                        <i class="fas fa-user-lock"></i>
                    </div>
                    <h3>Review Privacy Settings</h3>
                    <p>Regularly check who can see your posts, photos, and personal information. Limit visibility to friends only.</p>
                    <div class="tip-example">
                        <strong>Check:</strong> Profile visibility, tagged photos, friend lists
                    </div>
                </div>

                <div class="tip-card">
                    <div class="tip-icon">
                        <i class="fas fa-map-marker-alt"></i>
                    </div>
                    <h3>Don't Overshare Location</h3>
                    <p>Avoid posting real-time locations or travel plans. Share vacation photos after you return home.</p>
                    <div class="tip-example">
                        <strong>Risk:</strong> Burglars know when you're away from home
                    </div>
                </div>

                <div class="tip-card">
                    <div class="tip-icon">
                        <i class="fas fa-user-friends"></i>
                    </div>
                    <h3>Be Selective with Friend Requests</h3>
                    <p>Only accept requests from people you know. Fake profiles are used for scams and data harvesting.</p>
                    <div class="tip-example">
                        <strong>Warning:</strong> Check mutual friends and profile history
                    </div>
                </div>
            </div>
        </div>

        <!-- Safe Browsing -->
        <div class="tips-category">
            <h2><i class="fas fa-globe"></i> Safe Browsing</h2>
            <div class="tips-grid">
                <div class="tip-card">
                    <div class="tip-icon">
                        <i class="fas fa-shield-alt"></i>
                    </div>
                    <h3>Look for HTTPS</h3>
                    <p>Always check for "https://" and a padlock icon before entering sensitive information on websites.</p>
                    <div class="tip-example">
                        <strong>Secure:</strong> <i class="fas fa-lock"></i> https://example.com
                    </div>
                </div>

                <div class="tip-card">
                    <div class="tip-icon">
                        <i class="fas fa-download"></i>
                    </div>
                    <h3>Verify Downloads</h3>
                    <p>Only download software from official sources. Scan files with antivirus before opening.</p>
                    <div class="tip-example">
                        <strong>Safe:</strong> Official app stores and developer websites
                    </div>
                </div>

                <div class="tip-card">
                    <div class="tip-icon">
                        <i class="fas fa-wifi"></i>
                    </div>
                    <h3>Secure Public WiFi Use</h3>
                    <p>Avoid accessing sensitive accounts on public WiFi. Use a VPN for encrypted connections.</p>
                    <div class="tip-example">
                        <strong>Use:</strong> VPN services like ProtonVPN or NordVPN
                    </div>
                </div>
            </div>
        </div>

        <!-- Quick Action Tips -->
        <div class="action-tips">
            <h2><i class="fas fa-bolt"></i> Quick Actions You Can Take Now</h2>
            <ul class="action-list">
                <li><i class="fas fa-check"></i> Update all your passwords to strong, unique ones</li>
                <li><i class="fas fa-check"></i> Enable 2FA on your email, banking, and social media accounts</li>
                <li><i class="fas fa-check"></i> Review privacy settings on all social media platforms</li>
                <li><i class="fas fa-check"></i> Install security updates on all your devices</li>
                <li><i class="fas fa-check"></i> Set up a password manager</li>
                <li><i class="fas fa-check"></i> Check your email for data breach notifications at <a href="https://haveibeenpwned.com" target="_blank">HaveIBeenPwned.com</a></li>
            </ul>
        </div>

        <div class="tips-cta">
            <p>Want to test your knowledge?</p>
            <a href="quiz.php" class="btn btn-primary">Take the Quiz</a>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
/**
 * SmartNet JavaScript
 * Digital Literacy Platform
 * Handles interactivity and user experience enhancements
 */

// ============================================
// MOBILE NAVIGATION TOGGLE
// ============================================
document.addEventListener("DOMContentLoaded", function () {
  const navToggle = document.getElementById("navToggle");
  const navMenu = document.getElementById("navMenu");

  if (navToggle && navMenu) {
    navToggle.addEventListener("click", function () {
      navMenu.classList.toggle("active");

      // Update aria-expanded for accessibility
      const isExpanded = navMenu.classList.contains("active");
      navToggle.setAttribute("aria-expanded", isExpanded);
    });

    // Close menu when clicking outside
    document.addEventListener("click", function (event) {
      const isClickInsideNav =
        navToggle.contains(event.target) || navMenu.contains(event.target);

      if (!isClickInsideNav && navMenu.classList.contains("active")) {
        navMenu.classList.remove("active");
        navToggle.setAttribute("aria-expanded", "false");
      }
    });

    // Close menu when clicking a nav link
    const navLinks = navMenu.querySelectorAll("a");
    navLinks.forEach((link) => {
      link.addEventListener("click", function () {
        navMenu.classList.remove("active");
        navToggle.setAttribute("aria-expanded", "false");
      });
    });
  }
});

// ============================================
// QUIZ FORM VALIDATION
// ============================================
const quizForm = document.getElementById("quizForm");

if (quizForm) {
  quizForm.addEventListener("submit", function (event) {
    const questions = quizForm.querySelectorAll(".question-card");
    let allAnswered = true;
    let firstUnanswered = null;

    questions.forEach(function (question) {
      const radioButtons = question.querySelectorAll('input[type="radio"]');
      const isAnswered = Array.from(radioButtons).some(
        (radio) => radio.checked
      );

      if (!isAnswered) {
        allAnswered = false;
        if (!firstUnanswered) {
          firstUnanswered = question;
        }
        question.style.borderLeft = "4px solid #ef4444";
      } else {
        question.style.borderLeft = "none";
      }
    });

    if (!allAnswered) {
      event.preventDefault();
      alert("Please answer all questions before submitting the quiz.");

      // Scroll to first unanswered question
      if (firstUnanswered) {
        firstUnanswered.scrollIntoView({ behavior: "smooth", block: "center" });
      }
    } else {
      // All questions answered, show loading state
      const submitButton = quizForm.querySelector('button[type="submit"]');
      if (submitButton) {
        submitButton.disabled = true;
        submitButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...';
      }
    }
  });

  // Add visual feedback when selecting an option
  const optionLabels = quizForm.querySelectorAll(".option-label");
  optionLabels.forEach(function (label) {
    label.addEventListener("click", function () {
      const question = label.closest(".question-card");
      question.style.borderLeft = "none";
    });
  });
}


// ============================================
// SMOOTH SCROLL FOR ANCHOR LINKS
// ============================================
document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
  anchor.addEventListener("click", function (event) {
    const href = this.getAttribute("href");

    // Only apply smooth scroll if it's a valid anchor
    if (href !== "#" && document.querySelector(href)) {
      event.preventDefault();

      document.querySelector(href).scrollIntoView({
        behavior: "smooth",
        block: "start",
      });
    }
  });
});

// ============================================
// ANIMATE SCORE CIRCLE ON RESULTS PAGE
// ============================================
window.addEventListener("load", function () {
  const scoreProgress = document.querySelector(".score-progress");

  if (scoreProgress) {
    // Trigger animation after a short delay
    setTimeout(function () {
      scoreProgress.style.transition = "stroke-dashoffset 1.5s ease-in-out";
    }, 100);
  }
});

// ============================================
// FORM INPUT ENHANCEMENTS
// ============================================
// Add focus styles to form inputs
const formInputs = document.querySelectorAll(
  'input[type="text"], input[type="email"], textarea'
);

formInputs.forEach(function (input) {
  input.addEventListener("focus", function () {
    this.parentElement.classList.add("focused");
  });

  input.addEventListener("blur", function () {
    this.parentElement.classList.remove("focused");
  });
});

// ============================================
// ACCESSIBILITY ENHANCEMENTS
// ============================================
// Add keyboard navigation for custom radio buttons
const radioInputs = document.querySelectorAll(
  '.option-label input[type="radio"]'
);

radioInputs.forEach(function (radio) {
  radio.addEventListener("keydown", function (event) {
    if (event.key === "Enter" || event.key === " ") {
      event.preventDefault();
      this.checked = true;
      this.dispatchEvent(new Event("change"));
    }
  });
});

// ============================================
// PERFORMANCE: LAZY LOAD IMAGES (if any added later)
// ============================================
if ("IntersectionObserver" in window) {
  const lazyImages = document.querySelectorAll("img[data-src]");

  const imageObserver = new IntersectionObserver(function (entries, observer) {
    entries.forEach(function (entry) {
      if (entry.isIntersecting) {
        const img = entry.target;
        img.src = img.dataset.src;
        img.removeAttribute("data-src");
        imageObserver.unobserve(img);
      }
    });
  });

  lazyImages.forEach(function (img) {
    imageObserver.observe(img);
  });
}

// ============================================
// CONSOLE MESSAGE (Easter Egg)
// ============================================
console.log(
  "%c🛡️ SmartNet - Digital Literacy Platform",
  "color: #2563eb; font-size: 20px; font-weight: bold;"
);
console.log("%cStay safe online! 🌐", "color: #10b981; font-size: 14px;");
console.log(
  "%cInterested in the code? Check out our GitHub repository!",
  "color: #6b7280; font-size: 12px;"
);

<?php

/**
 * Home Page
 * SmartNet - Digital Literacy Platform
 */

$page_title = 'Home';
include 'includes/header.php';
?>

<!-- Hero Section -->
<section class="hero">
    <div class="container">
        <div class="hero-content">
            <h1>Stay Safe Online with <span class="highlight">SmartNet</span></h1>
            <p class="hero-subtitle">Learn digital literacy skills to protect yourself from scams, phishing, and online threats</p>
            <div class="hero-buttons">
                <a href="quiz.php" class="btn btn-primary">Take the Quiz</a>
                <a href="tips.php" class="btn btn-secondary">Learn Safety Tips</a>
            </div>
        </div>
        <div class="hero-stats">
            <div class="stat-card">
                <i class="fas fa-exclamation-triangle"></i>
                <h3>$10.3B</h3>
                <p>Lost to scams in 2023</p>
            </div>
            <div class="stat-card">
                <i class="fas fa-user-shield"></i>
                <h3>3.4B</h3>
                <p>Phishing emails sent daily</p>
            </div>
            <div class="stat-card">
                <i class="fas fa-lock"></i>
                <h3>80%</h3>
                <p>Breaches from weak passwords</p>
            </div>
        </div>
    </div>
</section>

<!-- Features Section -->
<section class="features">
    <div class="container">
        <h2 class="section-title">How SmartNet Helps You</h2>
        <div class="features-grid">
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-question-circle"></i>
                </div>
                <h3>Interactive Quiz</h3>
                <p>Test your digital literacy knowledge with our comprehensive quiz covering password security, phishing, and safe browsing.</p>
                <a href="quiz.php" class="feature-link">Start Quiz <i class="fas fa-arrow-right"></i></a>
            </div>

            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-lightbulb"></i>
                </div>
                <h3>Practical Tips</h3>
                <p>Learn actionable safety tips organized by category: passwords, phishing, social media, and safe browsing habits.</p>
                <a href="tips.php" class="feature-link">View Tips <i class="fas fa-arrow-right"></i></a>
            </div>

            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-book"></i>
                </div>
                <h3>Curated Resources</h3>
                <p>Access trusted learning materials from cybersecurity experts to deepen your understanding of online safety.</p>
                <a href="resources.php" class="feature-link">Explore Resources <i class="fas fa-arrow-right"></i></a>
            </div>
        </div>
    </div>
</section>

<!-- Why Section -->
<section class="why-section">
    <div class="container">
        <h2 class="section-title">Why Digital Literacy Matters</h2>
        <div class="why-content">
            <div class="why-text">
                <p>In today's digital world, <strong>everyone is a target</strong> for cybercriminals. From phishing emails to fake websites, online threats are constantly evolving.</p>
                <p>SmartNet empowers you with the knowledge to:</p>
                <ul class="check-list">
                    <li><i class="fas fa-check-circle"></i> Recognize and avoid phishing attempts</li>
                    <li><i class="fas fa-check-circle"></i> Create strong, secure passwords</li>
                    <li><i class="fas fa-check-circle"></i> Protect your privacy on social media</li>
                    <li><i class="fas fa-check-circle"></i> Browse safely and avoid malicious websites</li>
                    <li><i class="fas fa-check-circle"></i> Secure your devices and accounts</li>
                </ul>
            </div>
            <div class="why-image">
                <i class="fas fa-shield-alt"></i>
            </div>
        </div>
    </div>
</section>

<!-- CTA Section -->
<section class="cta-section">
    <div class="container">
        <h2>Ready to Become Digitally Literate?</h2>
        <p>Start your journey to safer internet usage today</p>
        <a href="quiz.php" class="btn btn-primary btn-large">Take the Quiz Now</a>
    </div>
</section>

<?php include 'includes/footer.php'; ?>